package com.example.yugabyte.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.yugabyte.ysql.YBClusterAwareDataSource;

@Configuration
public class YugabyteDataSourceConfig {
	
	@Value("${yugabyte.sql.datasource.url}")
	String jdbcUrl;

	@Value("${yugabyte.sql.datasource.user}")
	String user;

	@Value("${yugabyte.sql.datasource.password}")
	String password;

	
	@Bean
	public DataSource dataSource() {
		YBClusterAwareDataSource ds = new YBClusterAwareDataSource();
		ds.setUrl(jdbcUrl);
		ds.setUser(user);
		ds.setPassword(password);
		return ds;
	}
}
