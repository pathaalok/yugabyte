package com.example.yugabyte.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.yugabyte.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
}